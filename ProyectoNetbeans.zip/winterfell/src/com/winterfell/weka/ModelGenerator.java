
package com.winterfell.weka;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.StringTokenizer;
import weka.classifiers.Evaluation;
import weka.classifiers.lazy.IBk;
import weka.core.Instances;
import weka.core.Range;
import weka.core.converters.ArffLoader;
import weka.core.stemmers.SnowballStemmer;
import weka.core.stemmers.Stemmer;
import weka.core.tokenizers.WordTokenizer;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.StringToWordVector;

public class ModelGenerator {
    public static String tempInput = "temp.txt", entradaTrain = "rawinput.txt", 
    arffTrain = "train.arff", singlearffTest = "singletest.arff", 
    arffTest = "test.arff", stopwords = "stopwords.txt";
    
    public static void simulateDataMining() throws Exception{
        //cargar archivo arff de entrenamiento (Train)
	ArffLoader loader = FileLoader.getArffFromFile(entradaTrain, arffTrain);
	Instances train = loader.getDataSet();
        train.setClassIndex(train.numAttributes() - 1); //establecer la clase
        //cargar archivo arff de pruebas (Test)
        loader = FileLoader.getTestArff(arffTest);
	Instances test = loader.getDataSet();
        test.setClassIndex(test.numAttributes() - 1);   //establecer la clase
	
        //inicializar filtro y stemmer
	StringToWordVector filter = new StringToWordVector(200);
	Stemmer sb = new SnowballStemmer("spanish");
	filter.setStemmer(sb);
	filter.setStopwords(new File(stopwords));
	filter.setUseStoplist(true);
	filter.setMinTermFreq(8);
	filter.setWordsToKeep(100);
	filter.setLowerCaseTokens(false);
	filter.setInvertSelection(false);
	filter.setIDFTransform(false);
	filter.setTFTransform(false);
	filter.setAttributeIndices("first-last");
	filter.setDoNotOperateOnPerClassBasis(true);
	filter.setOutputWordCounts(true);
        
	//inicializar y setear WordTokenizer para el filtro
        WordTokenizer wordTok = new WordTokenizer();
	wordTok.setDelimiters(" \t\n\0.,;:'\"()?!");
	filter.setTokenizer(wordTok);
	filter.setInputFormat(train); //siempre tiene que ir de ultimo, si no hay error
        
        //aplicar el filtro a ambos conjuntos de datos
	Instances filteredTrain = Filter.useFilter(train, filter);
	Instances filteredTest = Filter.useFilter(test, filter);
        
        System.out.println(filteredTrain.toSummaryString()+"\n------------------------\n");
        System.out.println(filteredTest.toSummaryString()+"\n------------------------\n");
               
	int k = 3;
	IBk kVecinos = new IBk();
        kVecinos.setKNN(k);
        kVecinos.buildClassifier(filteredTrain);
        kVecinos.setWindowSize(0);
        
        //para imprimir resultado por tupla
        Evaluation eval = new Evaluation(filteredTrain);
        StringBuffer buffer = null;
        Range range = new Range("first-last");
        eval.evaluateModel(kVecinos, filteredTest, buffer, range, true);
        
        System.out.println(eval.toClassDetailsString());
        System.out.println(eval.toMatrixString());
        System.out.println(eval.toSummaryString(true));
//        System.out.println(buffer); //esta null
    }
    
    public static String getMention(String Titulo, String Resumen, String Palabras_Clave) throws Exception{
	
        //generar archivo arff con los parametros pasados 
        String header = "%	Clasificador de Trabajos Especiales de Grado\n%\n%	Mineria de Datos Sem II \n%\n%	De Freitas, De Tejada, Vergara\n%\n@relation ClasificadorTEG\n@ATTRIBUTE Titulo string\n@ATTRIBUTE Resumen string\n@ATTRIBUTE Palabras_Clave string\n@ATTRIBUTE Mencion {\'APLICACIONES EN INTERNET', 'BASES DE DATOS', 'CALCULO CIENTIFICO', 'COMPUTACION GRAFICA', 'INGENIERIA DE SOFTWARE', 'INTELIGENCIA ARTIFICIAL', 'MODELOS Y PROGRAMACION MATEMATICA', 'REDES DE COMPUTADORAS', 'SISTEMAS DE INFORMACION', 'SISTEMAS DISTRIBUIDOS Y PARALELOS', 'TECNOLOGIAS EDUCATIVAS'}\n@DATA\n";
	String toFile = header+"'"+Titulo+"', '"+Resumen+"', '"+Palabras_Clave+"', ?";
        System.out.println(toFile);
	
	File file = new File(singlearffTest);
	if (!file.exists()) { file.createNewFile();}

	FileWriter fw = new FileWriter(file.getAbsoluteFile());
	BufferedWriter bw = new BufferedWriter(fw);
	bw.write(toFile);
	bw.close();
	
	//Cargar el conjunto de entrenamiento (train)
        ArffLoader loader = FileLoader.getArffFromFile(entradaTrain, arffTrain);
	Instances train = loader.getDataSet();
        train.setClassIndex(train.numAttributes() - 1);
        
        //Cargar el conjunto de Pruebas (test) generado con los parametros
        loader.setFile(new File(singlearffTest));
	Instances test = loader.getDataSet();
        test.setClassIndex(test.numAttributes() - 1);
	
        // Inicializar y configurar filtro StringToWordVector
	StringToWordVector filter = new StringToWordVector(200);
	Stemmer sb = new SnowballStemmer("spanish");    //Incializar Stemmer como Porter Stemmer para el español
	filter.setStemmer(sb);  //asignar el Stemmer al filtro
	filter.setStopwords(new File(stopwords));   //Especificar el Stop List a utilizar
	filter.setUseStoplist(true);    //indicarle que utilice el stop list
	filter.setMinTermFreq(8);   //Frecuencia mínima de terminos
	filter.setWordsToKeep(100); //Maximo de palabras a mantener
	filter.setLowerCaseTokens(false);
	filter.setInvertSelection(false);
	filter.setIDFTransform(false);
	filter.setTFTransform(false);
	filter.setAttributeIndices("first-last");
	filter.setDoNotOperateOnPerClassBasis(true);
	filter.setOutputWordCounts(true);   //indicar que muestre el conteo de las palabras
	WordTokenizer wordTok = new WordTokenizer();    //Inicializar tokenizer
	wordTok.setDelimiters(" \t\n\0.,;:'\"()?!");    //indicar delimitadores al tokenizer
	filter.setTokenizer(wordTok);   //asignar el tokenizer como parametro del filtro
	filter.setInputFormat(train); //especificar el formato del conjunto de datos, siempre tiene que ir de ultimo, si no pueden presentarse errores
	
        //aplicar el filto a ambos conjuntos por igual para mantener homogeneidad y evitar incompatibilidad
        Instances filteredTrain = Filter.useFilter(train, filter);
	Instances filteredTest = Filter.useFilter(test, filter);
        
        System.out.println("------------------------ Train Set\n"+filteredTrain.toSummaryString()+"\n------------------------\n");
        System.out.println("------------------------ Test Set\n"+filteredTest.toSummaryString()+"\n------------------------\n");
               
	int k = 3; //número óptimo
	IBk kVecinos = new IBk();
        kVecinos.setKNN(k);
        kVecinos.buildClassifier(filteredTrain);
        kVecinos.setWindowSize(0);
        
        //para imprimir resultado por tupla
        Evaluation eval = new Evaluation(filteredTrain);
        StringBuffer buffer = new StringBuffer();
        Range range = new Range("first-last");
        eval.evaluateModel(kVecinos, filteredTest, buffer, range, true);
        
        System.out.println(eval.toClassDetailsString());
        System.out.println(eval.toMatrixString());
        System.out.println(eval.toSummaryString(true));
        StringTokenizer tokens = new StringTokenizer(buffer.toString(), ":");
        String tok = tokens.nextToken();
        tok = tokens.nextToken();
        tok = tokens.nextToken(" ");
        tok = tok.replaceAll(":", "");
        System.out.println("Mencion: "+tok);
        
	return tok;
    }
}
