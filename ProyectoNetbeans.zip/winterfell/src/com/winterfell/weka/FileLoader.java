
package com.winterfell.weka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import weka.core.converters.ArffLoader;

public class FileLoader {
    private static String header = "%	Clasificador de Trabajos Especiales de Grado\n%\n%	Mineria de Datos Sem II \n%\n%	De Freitas, De Tejada, Vergara\n%\n@relation ClasificadorTEG\n@ATTRIBUTE Titulo string\n@ATTRIBUTE Resumen string\n@ATTRIBUTE Palabras_Clave string\n@ATTRIBUTE Mencion {\'APLICACIONES EN INTERNET', 'BASES DE DATOS', 'CALCULO CIENTIFICO', 'COMPUTACION GRAFICA', 'INGENIERIA DE SOFTWARE', 'INTELIGENCIA ARTIFICIAL', 'MODELOS Y PROGRAMACION MATEMATICA', 'REDES DE COMPUTADORAS', 'SISTEMAS DE INFORMACION', 'SISTEMAS DISTRIBUIDOS Y PARALELOS', 'TECNOLOGIAS EDUCATIVAS'}\n@DATA\n";
    private static int lineno;
    private static int lineno_tesis;

    public static void setHeader(String header) {
	FileLoader.header = header;
    }
    
    private static String loadRawFile(String route, String destination) throws FileNotFoundException, IOException{
	lineno =0;
	lineno_tesis = 0;
	File f = new File(route);
	if (!f.exists()) {
	    System.out.println(route + " does not exist.");
	    return null;
	}
	BufferedReader sr = new BufferedReader(new InputStreamReader(new FileInputStream(route), "Cp1252"));
	FileWriter sw = new FileWriter(destination, false);
	String input, tesis = null;
	sw.write(header);
	int cont=0, cagCont=0;
	input = sr.readLine(); lineno++;
	while (input != null) {
	    if (!input.equalsIgnoreCase("")) {
		tesis = sanitizeString(input);
		input = sr.readLine();
		while (input != null && !input.equalsIgnoreCase("")) {
		    tesis = tesis + sanitizeString(input);
		    input = sr.readLine(); lineno++;
		}
		tesis = arreglarComillas(tesis);
		cont = ContarComillas(tesis);
		if (cont % 2 != 0) {
		    cagCont++;
		    System.out.println("ERROR # impar de atributos en linea "+ lineno+ " del archivo... Ignorando");
		} else if (cont % 2 == 0) {
		    if (cont == 8) {
			sw.write(tesis+"\n"); lineno_tesis++;
		    } else if(cont == 6){
			int pos = PosComillaComa(tesis);
			tesis = tesis.substring(0,pos) + "?," + tesis.substring(pos, tesis.length());
			sw.write(tesis+"\n"); lineno_tesis++;
		    }else if(cont >8){
			System.out.println("ERROR demasiados atributos en linea "+ lineno+ " del archivo... Ignorando");
		    }
		}
	    }
	    input = sr.readLine(); lineno++;
	}
	sr.close();
	sw.close();
	return destination;
    }
    
        private static String loadTesisUI(String route, String destination) throws FileNotFoundException, IOException{
	lineno =0;
	lineno_tesis = 0;
	File f = new File(route);
	if (!f.exists()) {
	    System.out.println(route + " does not exist.");
	    return null;
	}
	BufferedReader sr = new BufferedReader(new InputStreamReader(new FileInputStream(route), "Cp1252"));
	FileWriter sw = new FileWriter(destination, false);
	String input, tesis = null;
	sw.write(header);
	int cont=0, cagCont=0;
	input = sr.readLine(); lineno++;
	while (input != null) {
	    if (!input.equalsIgnoreCase("")) {
		tesis = sanitizeString(input);
		input = sr.readLine();
		while (input != null && !input.equalsIgnoreCase("")) {
		    tesis = tesis + sanitizeString(input);
		    input = sr.readLine(); lineno++;
		}
		tesis = arreglarComillas(tesis);
		cont = ContarComillas(tesis);
		if (cont % 2 != 0) {
		    cagCont++;
		    System.out.println("ERROR # impar de atributos en linea "+ lineno+ " del archivo... Ignorando");
		} else if (cont % 2 == 0) {
		    if (cont == 8) {
			sw.write(tesis+"\n"); lineno_tesis++;
		    } else if(cont == 6){
			int pos = PosComillaComa(tesis);
			tesis = tesis.substring(0,pos) + "?," + tesis.substring(pos, tesis.length());
			sw.write(tesis+"\n"); lineno_tesis++;
		    }else if(cont >8){
			System.out.println("ERROR demasiados atributos en linea "+ lineno+ " del archivo... Ignorando");
		    }
		}
	    }
	    input = sr.readLine(); lineno++;
	}
	sr.close();
	sw.close();
	return destination;
    }
    
    private static int ContarComillas(String linea) { 
	int cont=0;
	 for (int i=0; i<linea.length(); i++){
	    if(linea.charAt(i)=='\''){
	    cont++;
	    }
	 }
	return cont;
    }
    
    private static String arreglarComillas(String linea) { 
	 for (int i=0; i<linea.length(); i++){
	    if(linea.charAt(i)=='\''){
		if( (i+1 < linea.length() ) && ( linea.charAt(i+1)== ' ' || linea.charAt(i+1)=='\0' || linea.charAt(i+1)== '\'') ){
		    linea = linea.substring(0,i+1) + "," + linea.substring(i+1, linea.length());
		}
	    }
	 }
	return linea;
    }

    private static int PosComillaComa(String linea){
	int cont=0;
	for(int i=0; i< linea.length(); i++){
	    if(i!=0 && linea.charAt(i-1)=='\''){
		if(linea.charAt(i)==','){
		    cont++;
		    if(cont==2){
			return i+1;
		    }
		}
	    }
	}
	return 0;
    }
    
    private static String sanitizeString(String input){
	input = input.toUpperCase();
	input = input.replaceAll("Á", "A");
	input = input.replaceAll("É", "E");
	input = input.replaceAll("Í", "I");
	input = input.replaceAll("Ó", "O");
	input = input.replaceAll("Ú", "U");
	input = input.replaceAll("<", "");
	input = input.replaceAll(">", "");
	input = input.replaceAll("ª", "");
	input = input.replaceAll("º", "");
	input = input.replaceAll("Ñ", "N");
	input = input.replaceAll("TRABAJO ESPECIAL DE GRADO ", "");
	input = input.replaceAll("APLICACIONES( EN)? INTERNET", "APLICACIONES EN INTERNET");
	input = input.replaceAll("BASE(S)? DE DATO(S)?", "BASES DE DATOS");
	input = input.replaceAll("(TECNOLOGIA(S)? (EN|DE( LA)?) COMUNICACION(ES)? Y )?REDES DE COMPUTADOR(A|E)S", "REDES DE COMPUTADORAS");
	input = input.replaceAll("TECNOLOGIA(S)? EDUCATIVA(S)?", "TECNOLOGIAS EDUCATIVAS");
	input = input.replaceAll("INGENIER(I)?A DE(L)? SOFTWARE", "INGENIERIA DE SOFTWARE");
	input = input.replaceAll("SISTEMA(S)? DE INFORMACION", "TECNOLOGIAS EDUCATIVAS");
	input = input.replaceAll("COMPUTACION GRAFICA(S)?", "COMPUTACION GRAFICA");
	input = input.replaceAll("MODELO(S)?( ALEATORIO(S)?)? Y PROGRAMACION MATEMATICA", "MODELOS Y PROGRAMACION MATEMATICA");
	input = input.replaceAll("SISTEMA(S)? DISTRIBUIDO(S)? Y PARALELO(S)?", "SISTEMAS DISTRIBUIDOS Y PARALELOS");
	input = input.replaceAll("[-+^.:;{}#/@_%$&*?¿()]", "");
	return input;
    }
      
    public static ArffLoader getArffFromFile(String route, String destination) throws FileNotFoundException, IOException{
	ArffLoader loader = new ArffLoader();
	loader.setFile(new File(loadRawFile(route, destination)));
	return loader;
    }
    
    public static ArffLoader getTestArff(String route) throws FileNotFoundException, IOException{
	ArffLoader loader = new ArffLoader();
	loader.setFile(new File(route));
	return loader;
    }
}
